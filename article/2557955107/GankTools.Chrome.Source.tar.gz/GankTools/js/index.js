$(function(){
    //笔记管理
    $('#noteManage').click(function(){
        chrome.tabs.create({url :"http://www.ganktools.com/note" },function(){});
    });
    //后台管理
    $('#adminManage').click(function(){
        chrome.tabs.create({url :"http://www.ganktools.com/admin/index" },function(){});
    });
    //后台管理
    $('#myBlog').click(function(){
        chrome.tabs.create({url :"http://www.ganktools.com" },function(){});
    });
})
